$fs = 0.1;  // Don't generate smaller facets than 0.1 mm
$fa = 5;    // Don't generate larger angles than 5 

union(){
difference() {
    union(){
        difference() {
           translate([0,0,]) cylinder(20,30,30+20);
           translate([0,0,2]) cylinder(20,30-1,30+20-1);
        }
        translate([0,0,15*1])difference() {
           translate([0,0,0]) cylinder(20,30,30+20);
           translate([0,0,1]) cylinder(20,30-1,30+20-1);
        }
        translate([0,0,15*2])difference() {
           translate([0,0,0]) cylinder(20,30,30+20);
           translate([0,0,1]) cylinder(20,30-1,30+20-1);
        }
        translate([0,0,15*3])difference() {
           translate([0,0,0]) cylinder(20,30,30+20);
           translate([0,0,1]) cylinder(20,30-1,30+20-1);
        }
        translate([0,0,15*4])difference() {
           translate([0,0,0]) cylinder(20,30,30+20);
           translate([0,0,1]) cylinder(20,30-1,30+20-1);
        }
    }
    translate([0,0,1]) cylinder(h=70,r=30);
}
    translate([0,0,55])difference() {
       translate([0,0,0]) cylinder(50-25,17/2,30);
       translate([0,0,0]) cylinder(h=70,r=17/2);
        rotate(a=[0,0,45]){
       translate([20,0,0]) cylinder(h=100,r=4/2);
       translate([-20,0,0]) cylinder(h=100,r=4/2);
       translate([0,20,0]) cylinder(h=100,r=4/2);
       translate([0,-20,0]) cylinder(h=100,r=4/2);
        }
    }
translate([0,0,0])difference() {    
 translate([0,0,0]) cylinder(h=100,r=(17/2)+3);
 translate([0,0,0]) cylinder(h=100,r=(17/2));
    
    rotate(a=[0,0,22.5]){
      rotate(a=[0,0,0])translate([-40,-2,0]) cube([80,4,50]);
      rotate(a=[0,0,90])translate([-40,-2,0]) cube([80,4,50]);
      rotate(a=[0,0,45])translate([-40,-2,0]) cube([80,4,50]);
      rotate(a=[0,0,-45])translate([-40,-2,0]) cube([80,4,50]);
    }
    
 translate([0,0,90]) rotate(a=[90,0,90]) translate([0,0,-15]) cylinder(h=30,r=4/2);
    
}

translate([0,0,0])difference() {    
 translate([0,0,0]) cylinder(h=80,r=30);
 translate([0,0,0]) cylinder(h=80,r=30-3);
    
  rotate(a=[0,0,0])translate([-40,-5,0]) cube([80,10,100]);
  rotate(a=[0,0,90])translate([-40,-5,0]) cube([80,10,100]);
  rotate(a=[0,0,45])translate([-40,-5,0]) cube([80,10,100]);
  rotate(a=[0,0,-45])translate([-40,-5,0]) cube([80,10,100]);
    
}
}