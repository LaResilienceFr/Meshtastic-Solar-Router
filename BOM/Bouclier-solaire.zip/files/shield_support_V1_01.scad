$fs = 0.1;  // Don't generate smaller facets than 0.1 mm
$fa = 5;    // Don't generate larger angles than 5 
difference() {
    union() {
        difference() {
                prism(30, 80, 200);
                translate([7,18,10]) prism(30, 70, 200);
                translate([7,-18,10]) prism(30, 70, 200);
            
                translate([-1,-1,180]) cube([32,32,32]);
                translate([78,-1,-1]) cube([32,32,32]);
            
                translate([20,5,-1]) cylinder(h=15, r=2);
                translate([60,5,-1]) cylinder(h=15, r=2);
                translate([20,25,-1]) cylinder(h=15, r=2);
                translate([60,25,-1]) cylinder(h=15, r=2);
            
            
                //translate([0,26,165])rotate(a=[90,0,90]) cylinder(h=10, r=2);
                //translate([0,4,165])rotate(a=[90,0,90]) cylinder(h=10, r=2);
            
                //translate([-1,5,175])rotate(a=[0,90,0]) cylinder(h=15, r=2);
                //translate([-1,25,175])rotate(a=[0,90,0]) cylinder(h=15, r=2);
            
                //translate([-1,5,105])rotate(a=[0,90,0]) cylinder(h=15, r=2);
                //translate([-1,25,105])rotate(a=[0,90,0]) cylinder(h=15, r=2);
            
            
                translate([20,5,15])rotate(a=[0,90,90]) cylinder(h=30, r=4);
                translate([60,5,15])rotate(a=[0,90,90]) cylinder(h=30, r=4);
                
                translate([-1,15,-20])rotate(a=[0,90,0]) cylinder(h=80, r=25);
            
                //translate([-5,26,180])rotate(a=[0,90,45]) cylinder(h=15, r=5);
                //translate([-5,4,180])rotate(a=[0,90,-45]) cylinder(h=15, r=5);
            
                //translate([-5,26,110])rotate(a=[0,90,45]) cylinder(h=15, r=5);
                //translate([-5,4,110])rotate(a=[0,90,-45]) cylinder(h=15, r=5);
            
        }
           translate([0,15,155])rotate(a=[0,90,0]){
               rotate(a=[0,0,45]){
                   translate([0,0,0]) cylinder(h=7,r=30);  
               }
           }
    }
    translate([0,15,155])rotate(a=[0,90,0]){
               rotate(a=[0,0,45]){
                   //translate([0,0,0]) cylinder(h=7,r=30);  
                   translate([0,0,0]) cylinder(h=100,r=(17/2)+3.5);        
                   translate([20,0,0]) cylinder(h=100,r=4/2);
                   translate([-20,0,0]) cylinder(h=100,r=4/2);
                   translate([0,20,0]) cylinder(h=100,r=4/2);
                   translate([0,-20,0]) cylinder(h=100,r=4/2);
               }
           }
}

module prism(l, w, h) {
       polyhedron(points=[
               [0,0,h],           // 0    front top corner
               [0,0,0],[w,0,0],   // 1, 2 front left & right bottom corners
               [0,l,h],           // 3    back top corner
               [0,l,0],[w,l,0]    // 4, 5 back left & right bottom corners
       ], faces=[ // points for all faces must be ordered clockwise when looking in
               [0,2,1],    // top face
               [3,4,5],    // base face
               [0,1,4,3],  // h face
               [1,2,5,4],  // w face
               [0,3,5,2],  // hypotenuse face
       ]);
}